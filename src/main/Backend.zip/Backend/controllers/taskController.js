const Task = require("../models/Tasks");
const redis = require("../middleware/cache");

// 🔥 GET /tasks - Fetch paginated & filtered tasks (for logged-in user)
const getTasks = async (req, res, next) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ message: "Unauthorized. Please log in." });
        }

        const userId = req.user.id; // Get logged-in user ID
        console.log("Fetching tasks for user:", userId); // Debugging Log

        const { page = 1, limit = 10, priority, dueDate } = req.query;

        let filter = { author: userId };

        if (priority) filter.priority = priority;
        if (dueDate) filter.dueDate = { $lte: new Date(dueDate) };

        const tasks = await Task.find(filter)
            .limit(parseInt(limit))
            .skip((parseInt(page) - 1) * parseInt(limit))
            .sort({ dueDate: 1 });

        const totalTasks = await Task.countDocuments(filter);

        console.log(`✅ Total tasks found for user ${userId}:`, totalTasks);

        res.json({
            tasks,
            page: parseInt(page),
            totalPages: Math.ceil(totalTasks / limit),
            totalTasks
        });
    } catch (error) {
        console.error("❌ Error fetching tasks:", error);
        next(error);
    }
};

// 🔥 POST /tasks - Create a new task (for logged-in user)
const createTask = async (req, res, next) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ message: "Unauthorized. Please log in." });
        }

        const userId = req.user.id;
        console.log("Creating task for user:", userId);

        const { name, startDate, endDate, priority = "Low", type } = req.body;

        // ✅ Validate required fields
        if (!name || !startDate || !endDate || !type) {
            return res.status(400).json({ message: "All fields are required!" });
        }

        // ✅ Ensure endDate is **AFTER** startDate
        const parsedStartDate = new Date(startDate);
        const parsedEndDate = new Date(endDate);

        if (parsedEndDate <= parsedStartDate) {
            return res.status(400).json({ message: "End date must be later than start date." });
        }

        const task = new Task({
            author: userId,
            name,
            startDate: parsedStartDate,
            dueDate: parsedEndDate,
            priority,
            type
        });

        await task.save();
        console.log("✅ Task created successfully:", task);

        // ✅ Clear cache so that next GET request fetches new data
        await redis.client.del("/api/tasks");

        res.status(201).json({ message: "Task created successfully!", task });
    } catch (error) {
        console.error("❌ Error creating task:", error);
        res.status(500).json({ message: "Internal Server Error", error: error.message });
        next(error);
    }
};

module.exports = { getTasks, createTask };
